const apiKey = '246e8403ccd24836a8e44901242011'; // Replace with your OpenWeatherMap API key

document.getElementById('search-btn').addEventListener('click', () => {
  const city = document.getElementById('city-input').value;
  if (city) {
    getWeather(city);
  } else {
    alert('Please enter a city name.');
  }
});

function getWeather(city) {
  const url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city}`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      if (data.error) {
        // Show error message if the city is not found
        document.getElementById('error-message').classList.remove('hidden');
        document.getElementById('weather-info').classList.add('hidden');
      } else {
        // Hide error and display weather info
        document.getElementById('error-message').classList.add('hidden');
        document.getElementById('weather-info').classList.remove('hidden');

        document.getElementById('city-name').textContent = `${data.location.name}, ${data.location.country}`;
        document.getElementById('temperature').textContent = `Temperature: ${data.current.temp_c}°C`;
        document.getElementById('description').textContent = `Weather: ${data.current.condition.text}`;
        document.getElementById('humidity').textContent = `Humidity: ${data.current.humidity}%`;
      }
    })
    .catch(error => {
      console.error('Error fetching weather data:', error);
      alert('Error fetching data. Please try again later.');
    });
}
